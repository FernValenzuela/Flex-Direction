# Instructions  

---

Modify the flex-direction of `.one`, `.two`, `.three`, and `.four` in
'style.css' so the flex items match the following patterns:

**Part 1:**

1 2 3


**Part 2:**

1

2

3

**Part 3:**

3 2 1

**Part 4:**

3

2

1