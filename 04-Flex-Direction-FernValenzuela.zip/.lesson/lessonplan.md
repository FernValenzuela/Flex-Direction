# Lesson plan
  
---

```
/* Part 1 */
.one {
  flex-direction: row;
}


/* Part 2 */
.two {
  flex-direction: column;
}


/* Part 3 */
.three {
  flex-direction: row-reverse;
}


/* Part 2 */
.four {
  flex-direction: column-reverse;
}
```